addappid(1941540) 

addappid(1941541, 1, "47c1ea957b9ecc8662a117fa6b19eea01ed30ef06478a364110fe40afa4e9f0e") 
setManifestid(1941541, "7389755233066346624", 48103885967)

addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") 
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") 
setManifestid(228990, "1829726630299308803", 102931551)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") 
setManifestid(229002, "7260605429366465749", 50450161)

addappid(3262000) 
addappid(3269260) 
addappid(3269270) 
addappid(3269280)

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]